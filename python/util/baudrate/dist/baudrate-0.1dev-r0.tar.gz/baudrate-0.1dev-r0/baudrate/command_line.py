import baudrate

def main():
    rm = baudrate.realMain()
